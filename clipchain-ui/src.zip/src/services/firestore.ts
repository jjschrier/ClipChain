﻿import { db } from "../firebase/config";
import {
    collection,
    addDoc,
    getDocs,
    query,
    where,
    DocumentData,
    Timestamp
} from "firebase/firestore";

export interface Creator {
    id: string;
    wallet: string;
    username: string;
    role: "creator" | "fan";
    avatarUrl?: string;
}

export interface User {
    wallet: string;
    username: string;
    role: "creator" | "fan";
    avatarUrl?: string;
    joinedAt: Date;
}

export interface Video {
    creatorId: string;
    title: string;
    videoUrl: string;
    duration: number;
    postedAt: Date;
}

// Add user
export const addUser = async (user: User) => {
    return await addDoc(collection(db, "users"), user);
};

// Get creators
export async function getCreators(): Promise<Creator[]> {
    const snapshot = await getDocs(collection(db, "creators"));
    return snapshot.docs.map((doc) => {
        const data = doc.data();
        return {
            id: doc.id,
            wallet: data.wallet || "",
            username: data.username || "",
            role: data.role || "creator", // fallback
        };
    });
}

// Add video
export const addVideo = async (video: Video) => {
    return await addDoc(collection(db, "videos"), video);
};

// ✅ Fetch videos
export const fetchVideos = async (): Promise<Video[]> => {
    const snapshot = await getDocs(collection(db, "videos"));
    return snapshot.docs.map((doc) => doc.data() as Video);
};
