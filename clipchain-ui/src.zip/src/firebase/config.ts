﻿import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// ✅ Your fixed config
const firebaseConfig = {
    apiKey: "AIzaSyB5GySa6LDc2_FKzOksl8Stnv2KXiDX6FI",
    authDomain: "clip-chain.firebaseapp.com",
    databaseURL: "https://clip-chain-default-rtdb.firebaseio.com",
    projectId: "clip-chain",
    storageBucket: "clip-chain.appspot.com",
    messagingSenderId: "690901757971",
    appId: "1:690901757971:web:f5729b7ceb941ba814cfe6",
    measurementId: "G-9RW15VH4BM",
};

// ✅ This is required for Firebase modules to work
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// ✅ EXPORT for other files
export { db };