declare module "../firebase/config" {
    export const db: any;
}
