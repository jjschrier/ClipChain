﻿import { Connection, PublicKey } from '@solana/web3.js';
import { transferTokens } from './transferTokens';
import { WalletContextState } from '@solana/wallet-adapter-react';

export async function incrementWatchTime(
    wallet: WalletContextState,
    creator: string,
    connection: Connection
) {
    const viewer = wallet.publicKey;
    const creatorPub = new PublicKey(creator);

    if (!viewer) throw new Error("Viewer wallet not connected");

    const rewardAmount = 1;

    try {
        await transferTokens(connection, wallet, viewer, creatorPub, rewardAmount);
    } catch (error) {
        console.error('Yield transfer failed:', error);
        throw error;
    }
}
