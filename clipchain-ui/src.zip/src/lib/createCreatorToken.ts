﻿import {
    Connection,
    Keypair,
    SystemProgram,
    Transaction,
    PublicKey,
} from "@solana/web3.js";
import {
    TOKEN_PROGRAM_ID,
    MINT_SIZE,
    getMinimumBalanceForRentExemptMint,
    createInitializeMintInstruction,
} from "@solana/spl-token";
import { WalletContextState } from "@solana/wallet-adapter-react";

export async function createCreatorToken(
    connection: Connection,
    wallet: WalletContextState
): Promise<PublicKey> {
    if (!wallet.publicKey || !wallet.signTransaction) {
        throw new Error("Wallet not connected or missing signTransaction");
    }

    // Generate new mint keypair (you’ll sign this locally)
    const mint = Keypair.generate();

    const lamports = await getMinimumBalanceForRentExemptMint(connection);

    const transaction = new Transaction().add(
        // ✅ Fund new mint account from your connected wallet
        SystemProgram.createAccount({
            fromPubkey: wallet.publicKey,
            newAccountPubkey: mint.publicKey,
            space: MINT_SIZE,
            lamports,
            programId: TOKEN_PROGRAM_ID,
        }),
        // ✅ Initialize it as a token mint
        createInitializeMintInstruction(
            mint.publicKey,
            9, // decimals
            wallet.publicKey, // mint authority
            wallet.publicKey // freeze authority
        )
    );

    // ✅ Set recent blockhash & payer
    const { blockhash } = await connection.getLatestBlockhash();
    transaction.recentBlockhash = blockhash;
    transaction.feePayer = wallet.publicKey;

    // ✅ Sign with mint account (locally)
    transaction.partialSign(mint);

    // ✅ Let Phantom sign with your wallet
    const signedTx = await wallet.signTransaction(transaction);

    const txid = await connection.sendRawTransaction(signedTx.serialize());
    await connection.confirmTransaction(txid, "confirmed");

    console.log("✅ Mint created at:", mint.publicKey.toBase58());
    return mint.publicKey;
}
