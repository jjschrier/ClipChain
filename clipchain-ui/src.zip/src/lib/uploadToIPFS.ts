﻿export async function uploadToIPFS(file: File): Promise<string> {
    const JWT = import.meta.env.VITE_PINATA_JWT;
    if (!JWT) throw new Error("Missing VITE_PINATA_JWT");

    const formData = new FormData();
    formData.append("file", file);

    const res = await fetch("https://api.pinata.cloud/pinning/pinFileToIPFS", {
        method: "POST",
        headers: {
            Authorization: `Bearer ${JWT}`,
        },
        body: formData,
    });

    if (!res.ok) {
        const errorText = await res.text();
        throw new Error("Pinata upload failed: " + errorText);
    }

    const data = await res.json();

    // ✅ Use your dedicated gateway
    return `https://tan-tired-firefly-179.mypinata.cloud/ipfs/${data.IpfsHash}`;
}
