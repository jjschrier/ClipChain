import { doc, getDoc, setDoc } from "firebase/firestore";
import { db } from "../firebase/config";

/**
 * Save the avatar URL to the user's document in Firestore.
 * This uses merge: true to avoid overwriting existing fields.
 */
export const saveAvatar = async (wallet: string, url: string) => {
    console.log("Writing to Firestore: ", { wallet, avatarUrl: url });
    await setDoc(doc(db, "users", wallet), { avatarUrl: url });
    console.log("Firestore write complete");
};

/**
 * Retrieve the avatar URL from Firestore for the given wallet address.
 * Returns null if no avatar is found.
 */
export const getAvatar = async (wallet: string): Promise<string | null> => {
    const docSnap = await getDoc(doc(db, "users", wallet));
    return docSnap.exists() ? docSnap.data().avatarUrl : null;
};
