﻿import { createMint } from "@solana/spl-token";
import { Connection, PublicKey, Signer, Keypair } from "@solana/web3.js";
import { WalletContextState } from "@solana/wallet-adapter-react";
import { db } from "../firebase/config";
import { doc, getDoc, setDoc, Timestamp } from "firebase/firestore";

export async function ensureCreatorToken(wallet: WalletContextState, connection: Connection): Promise<PublicKey> {
    if (!wallet.publicKey || !wallet.signTransaction) throw new Error("Wallet not connected");

    const creatorAddress = wallet.publicKey.toBase58();
    const docRef = doc(db, "creators", creatorAddress);
    let docSnap = await getDoc(docRef);
    let data = docSnap.exists() ? docSnap.data() : null;

    if (!data) {
        const defaultName = `Creator-${creatorAddress.slice(0, 5)}`;
        await setDoc(docRef, {
            displayName: defaultName,
            createdAt: Timestamp.now(),
        });
        data = { displayName: defaultName };
    }

    const displayName = data.displayName || `Creator-${creatorAddress.slice(0, 5)}`;
    const existingTokenMint = data.tokenMint;
    if (existingTokenMint) return new PublicKey(existingTokenMint);

    // Use system wallet or wallet cast as signer
    const payer = wallet as unknown as Signer;

    const mint = await createMint(
        connection,
        payer,                    // payer
        wallet.publicKey,        // mint authority
        null,                    // freeze authority
        6                        // decimals
    );

    await setDoc(docRef, {
        ...data,
        tokenMint: mint.toBase58(),
        tokenName: displayName,
        symbol: `$${displayName.replace(/\s+/g, '')}`,
        yieldRate: 0.1 // tokens per 30s as default
    }, { merge: true });

    return mint;
}
