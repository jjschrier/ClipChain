﻿import {
    Connection,
    PublicKey,
    Transaction,
    TransactionSignature,
    Signer
} from '@solana/web3.js';

import {
    getOrCreateAssociatedTokenAccount,
    createTransferInstruction
} from '@solana/spl-token';
import { WalletContextState } from '@solana/wallet-adapter-react';

const MINT_ADDRESS = new PublicKey('REPLACE_WITH_ACTUAL_MINT'); // Replace this

export async function transferTokens(
    connection: Connection,
    wallet: WalletContextState,
    from: PublicKey,
    to: PublicKey,
    amount: number
): Promise<TransactionSignature> {
    if (!wallet.publicKey || !wallet.signTransaction) {
        throw new Error("Wallet not connected or cannot sign transactions");
    }

    // ⚠️ Cast wallet to Signer for payer
    const payer = wallet as unknown as Signer;

    const fromToken = await getOrCreateAssociatedTokenAccount(
        connection,
        payer,
        MINT_ADDRESS,
        from
    );

    const toToken = await getOrCreateAssociatedTokenAccount(
        connection,
        payer,
        MINT_ADDRESS,
        to
    );

    const transferIx = createTransferInstruction(
        fromToken.address,
        toToken.address,
        wallet.publicKey,
        amount * 1_000_000 // assuming 6 decimals
    );

    const tx = new Transaction().add(transferIx);
    const signedTx = await wallet.signTransaction(tx);
    const sig = await connection.sendRawTransaction(signedTx.serialize());
    await connection.confirmTransaction(sig, 'confirmed');

    return sig;
}
