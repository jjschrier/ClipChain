// Fixes TS2688: fake firebase type module
declare module 'firebase' { }
