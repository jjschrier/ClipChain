﻿import { useState } from "react";
import { uploadToIPFS } from "../lib/uploadToIPFS";
import { useWallet } from "@solana/wallet-adapter-react";
import { saveAvatar } from "../lib/userService";

const UploadAvatar = ({ onUpload }: { onUpload: (url: string) => void }) => {
    const [file, setFile] = useState<File | null>(null);
    const [loading, setLoading] = useState(false);
    const { publicKey } = useWallet();

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0];
        if (selectedFile) {
            console.log("Selected file:", selectedFile.name);
            setFile(selectedFile);
        }
    };

    const handleUpload = async () => {
        if (!file) return alert("Please select a file.");
        if (!publicKey) return alert("Please connect your wallet.");

        setLoading(true);

        try {
            console.log("Uploading avatar to IPFS...");
            const url = await uploadToIPFS(file); // ✅ uploadToIPFS returns full URL
            console.log("Avatar uploaded to IPFS:", url);

            console.log("Saving avatar to Firestore...");
            await saveAvatar(publicKey.toBase58(), url);
            console.log("Avatar saved to Firestore successfully");

            onUpload(url);
        } catch (error) {
            console.error("Avatar upload error:", error);
            alert("Failed to upload avatar. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex flex-col gap-3 text-sm text-white w-64">
            <label htmlFor="avatar-upload" className="text-gray-300 font-medium">
                Choose Profile Picture
            </label>
            <input
                id="avatar-upload"
                type="file"
                accept="image/*"
                onChange={handleChange}
                className="text-xs text-white bg-gray-700 p-2 rounded border border-gray-600"
            />

            <button
                onClick={handleUpload}
                disabled={!file || loading}
                className={`mt-2 px-4 py-2 rounded text-sm font-medium transition ${loading
                        ? "bg-gray-600 cursor-wait"
                        : file
                            ? "bg-purple-600 hover:bg-purple-700"
                            : "bg-gray-600 cursor-not-allowed"
                    }`}
            >
                {loading ? "Uploading..." : "Upload Avatar"}
            </button>
        </div>
    );
};

export default UploadAvatar;
