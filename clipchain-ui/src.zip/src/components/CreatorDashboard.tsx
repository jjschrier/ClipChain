﻿import { useEffect, useState } from "react";
import { useWallet } from "@solana/wallet-adapter-react";
import { db } from "../firebase/config";
import { collection, getDocs } from "firebase/firestore";
import VideoCard from "./VideoCard";
import { ensureCreatorToken } from "../lib/ensureCreatorToken";
import {
    Connection,
    clusterApiUrl,
    PublicKey
} from "@solana/web3.js";
import {
    getAssociatedTokenAddress,
    getAccount,
} from "@solana/spl-token";

const CreatorDashboard = () => {
    const wallet = useWallet();
    const { publicKey } = wallet;

    const [myVideos, setMyVideos] = useState<any[]>([]);
    const [mintAddress, setMintAddress] = useState<string | null>(null);
    const [loadingToken, setLoadingToken] = useState(false);
    const [tokenBalance, setTokenBalance] = useState<number | null>(null);
    const [error, setError] = useState<string | null>(null);

    const connection = new Connection(clusterApiUrl("devnet"), "confirmed");

    useEffect(() => {
        const loadMyVideos = async () => {
            if (!publicKey) return;
            const snapshot = await getDocs(collection(db, "videos"));
            const vids = snapshot.docs
                .map((doc) => doc.data())
                .filter((v) => v.creator === publicKey.toBase58());
            setMyVideos(vids);

            if (vids[0]?.tokenMint) {
                setMintAddress(vids[0].tokenMint);
                await fetchTokenBalance(vids[0].tokenMint);
            }
        };
        loadMyVideos();
    }, [publicKey]);

    const fetchTokenBalance = async (mint: string) => {
        if (!publicKey) return;

        try {
            const mintPubkey = new PublicKey(mint);
            const ata = await getAssociatedTokenAddress(mintPubkey, publicKey);
            const account = await getAccount(connection, ata);
            const balance = Number(account.amount) / 1_000_000_000; // 9 decimals
            setTokenBalance(balance);
        } catch (err) {
            console.warn("⚠️ Could not fetch token balance:", err);
            setTokenBalance(null);
        }
    };

    const tokenSymbol = publicKey ? `$${publicKey.toBase58().slice(0, 5)}...` : "???";

    const handleCreateToken = async () => {
        if (!wallet.publicKey || !wallet.signTransaction) {
            alert("Connect your wallet first.");
            return;
        }

        try {
            setLoadingToken(true);
            setError(null);
            const mint = await ensureCreatorToken(wallet, connection);
            setMintAddress(mint.toBase58());
            await fetchTokenBalance(mint.toBase58());
        } catch (err) {
            console.error(err);
            setError("Token creation failed. See console for details.");
        } finally {
            setLoadingToken(false);
        }
    };

    return (
        <div className="space-y-8">
            <h1 className="text-2xl font-bold">{tokenSymbol} Your Creator Dashboard</h1>

            <div className="bg-[#0a0a23] text-white p-4 rounded shadow space-y-2">
                <p className="font-medium">Your Token: {tokenSymbol}</p>
                {mintAddress && (
                    <p className="text-sm text-green-400 break-all">
                        ✅ Mint Address: {mintAddress}
                    </p>
                )}
                {tokenBalance !== null && (
                    <p className="text-sm text-blue-400">
                        💰 Balance: {tokenBalance} {tokenSymbol}
                    </p>
                )}
                <p className="text-sm text-gray-400">Fan token features coming soon.</p>

                {error && (
                    <p className="text-red-400 text-sm">{error}</p>
                )}

                <button
                    onClick={handleCreateToken}
                    disabled={loadingToken}
                    className="mt-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded text-sm disabled:opacity-50"
                >
                    {loadingToken ? "Creating Token..." : "Create My Fan Token"}
                </button>
            </div>

            <div className="mt-6">
                <h2 className="text-xl font-semibold mb-4">Your Videos</h2>
                {myVideos.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                        {myVideos.map((video, i) => (
                            <VideoCard
                                key={i}
                                title={video.title}
                                url={video.videoUrl}
                                tokenMint={video.tokenMint}
                            />
                        ))}
                    </div>
                ) : (
                    <p className="text-gray-400">No videos uploaded yet.</p>
                )}
            </div>
        </div>
    );
};

export default CreatorDashboard;
