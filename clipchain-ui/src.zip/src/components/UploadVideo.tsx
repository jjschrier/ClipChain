import { useState } from "react";
import { uploadToIPFS } from "../lib/uploadToIPFS";
import { db } from "../firebase/config";
import { collection, addDoc, Timestamp } from "firebase/firestore";
import { useWallet } from "@solana/wallet-adapter-react";
import { ensureCreatorToken } from "../lib/ensureCreatorToken";
import { Connection, clusterApiUrl } from "@solana/web3.js";

interface UploadVideoProps {
    onUpload: (video: { title: string; url: string; tokenMint: string }) => void;
}

const UploadVideo: React.FC<UploadVideoProps> = ({ onUpload }) => {
    const [title, setTitle] = useState("");
    const [file, setFile] = useState<File | null>(null);
    const [loading, setLoading] = useState(false);

    const wallet = useWallet();
    const { publicKey } = wallet;

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selected = e.target.files?.[0];
        if (selected) {
            setFile(selected);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!file || !title || !publicKey || !wallet.signTransaction) {
            return alert("Please connect your wallet, enter title, and choose a file.");
        }

        setLoading(true);
        try {
            const videoUrl = await uploadToIPFS(file);
            const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
            const tokenMint = await ensureCreatorToken(wallet, connection);

            await addDoc(collection(db, "videos"), {
                title,
                videoUrl,
                creator: publicKey.toBase58(),
                tokenMint: tokenMint.toBase58(),
                createdAt: Timestamp.now(),
            });

            onUpload({ title, url: videoUrl, tokenMint: tokenMint.toBase58() });
            setTitle("");
            setFile(null);
        } catch (error) {
            console.error("❌ Upload error:", error);
            alert("Video upload failed. Try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-lg max-w-xl mx-auto p-6 space-y-4">
            <h2 className="text-2xl font-semibold text-gray-800">🎬 Upload Video</h2>
            <input
                type="text"
                placeholder="Enter video title..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                className="w-full border border-gray-300 rounded px-3 py-2 text-black focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <input
                type="file"
                accept="video/*"
                onChange={handleFileChange}
                required
                className="w-full bg-gray-50 border border-gray-300 rounded px-3 py-2 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:bg-blue-600 file:text-white hover:file:bg-blue-700"
            />
            <button
                type="submit"
                disabled={loading}
                className={`w-full py-2 rounded font-medium transition ${loading ? "bg-gray-400" : "bg-green-600 hover:bg-green-700 text-white"
                    }`}
            >
                {loading ? "Uploading..." : "Upload Video"}
            </button>
        </form>
    );
};

export default UploadVideo;
