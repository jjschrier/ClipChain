import AirdropButton from "./SubscribeButton";

interface Props {
    title: string;
    url: string;
    tokenMint: string;
}

const VideoCard: React.FC<Props> = ({ title, url, tokenMint }) => {
    return (
        <div className="bg-gray-800 rounded-lg overflow-hidden shadow-lg p-4">
            <video src={url} controls className="w-full rounded" />
            <h3 className="text-white font-semibold text-lg mt-2">{title}</h3>
            <p className="text-sm text-gray-400 mb-2">Token Mint: {tokenMint}</p>
            <AirdropButton mintAddress={tokenMint} />
        </div>
    );
};

export default VideoCard;
