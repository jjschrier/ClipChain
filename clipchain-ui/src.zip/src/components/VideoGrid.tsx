interface Video {
    title: string;
    url: string;
    tokenMint: string;
}

interface VideoGridProps {
    videos: Video[];
}

const VideoGrid: React.FC<VideoGridProps> = ({ videos }) => {
    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {videos.map((video, index) => (
                <div key={index} className="bg-gray-900 rounded-lg p-4 shadow">
                    <video src={video.url} controls className="w-full rounded mb-2" />
                    <h3 className="text-lg font-semibold">{video.title}</h3>
                    <p className="text-sm text-gray-400">Token Mint: {video.tokenMint}</p>
                </div>
            ))}
        </div>
    );
};

export default VideoGrid;
