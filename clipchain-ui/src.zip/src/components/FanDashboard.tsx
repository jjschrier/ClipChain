import React, { useEffect, useState } from "react";
import { getCreators } from "../services/firestore";

interface Creator {
    id: string;
    wallet: string;
    username: string;
    role: "creator" | "fan";
    avatarUrl?: string;
}

const FanDashboard: React.FC = () => {
    const [creators, setCreators] = useState<Creator[]>([]);

    useEffect(() => {
        getCreators().then(setCreators);
    }, []);

    return (
        <div>
            <h1>Support a Creator</h1>
            <ul>
                {creators.map((c) => (
                    <li key={c.id}>
                        <img src={c.avatarUrl || "https://via.placeholder.com/50"} alt="avatar" width={50} />
                        <strong>{c.username}</strong> � Wallet: {c.wallet}
                        <button onClick={() => alert(`Support ${c.username}`)}>Support</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default FanDashboard;
