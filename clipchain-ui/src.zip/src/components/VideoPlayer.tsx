﻿import React, { useEffect, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getDoc, doc } from 'firebase/firestore';
import { db } from '../firebase/config';
import { useWallet, useConnection } from '@solana/wallet-adapter-react';
import { incrementWatchTime } from '../lib/incrementWatchTime';

const VideoPlayer: React.FC = () => {
    const { videoId } = useParams<{ videoId: string }>();
    const [videoData, setVideoData] = useState<any>(null);
    const videoRef = useRef<HTMLVideoElement>(null);
    const wallet = useWallet();
    const { connection } = useConnection();

    // Fetch video metadata
    useEffect(() => {
        const fetchVideo = async () => {
            if (!videoId) return;
            const docRef = doc(db, 'videos', videoId);
            const docSnap = await getDoc(docRef);
            if (docSnap.exists()) {
                setVideoData(docSnap.data());
            }
        };
        fetchVideo();
    }, [videoId]);

    // Track watch time and reward tokens
    useEffect(() => {
        if (!wallet.publicKey || !wallet.signTransaction || !videoData?.creator) return;

        const interval = setInterval(async () => {
            if (
                videoRef.current &&
                !videoRef.current.paused &&
                !videoRef.current.ended &&
                videoRef.current.readyState >= 2
            ) {
                try {
                    await incrementWatchTime(wallet, videoData.creator, connection);
                    console.log(`⏱️ Yield updated for ${wallet.publicKey?.toBase58?.()}`);
                } catch (error) {
                    console.error('❌ Yield error:', error);
                }
            }
        }, 10000); // every 10 seconds

        return () => clearInterval(interval);
    }, [wallet.publicKey, videoData, connection]);

    if (!videoData) return <div>Loading video...</div>;

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <h1 className="text-2xl font-bold mb-4">{videoData.title}</h1>
            <video
                ref={videoRef}
                controls
                className="w-full rounded-xl shadow"
                src={videoData.videoUrl}
            />
            <p className="text-sm text-gray-500 mt-2">Creator: {videoData.creator}</p>
        </div>
    );
};

export default VideoPlayer;
