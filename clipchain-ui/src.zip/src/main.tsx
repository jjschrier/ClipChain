﻿import { Buffer } from "buffer"; // ✅ Add this at the top
window.Buffer = Buffer;          // ✅ Inject Buffer globally

import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";

import { WalletProvider } from "@solana/wallet-adapter-react";
import { ConnectionProvider } from "@solana/wallet-adapter-react";
import { PhantomWalletAdapter } from "@solana/wallet-adapter-wallets";

const rootElement = document.getElementById("root");
if (!rootElement) throw new Error("Failed to find the root element");

const endpoint = "https://api.devnet.solana.com"; // ✅ safer for testing
const wallets = [new PhantomWalletAdapter()];

ReactDOM.createRoot(rootElement).render(
    <React.StrictMode>
        <ConnectionProvider endpoint={endpoint}>
            <WalletProvider wallets={wallets} autoConnect>
                <App />
            </WalletProvider>
        </ConnectionProvider>
    </React.StrictMode>
);
