﻿import { FC, useMemo, useState, useEffect } from "react";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import UploadVideo from "./components/UploadVideo";
import VideoGrid from "./components/VideoGrid";
import UploadAvatar from "./components/UploadAvatar";
import CreatorDashboard from "./components/CreatorDashboard";
import FanDashboard from "./components/FanDashboard";
import { getAvatar } from "./lib/userService";
import { fetchVideos } from "./services/firestore";

interface Video {
    title: string;
    url: string;
    tokenMint: string;
}

const AppRoutes: FC = () => {
    const [videos, setVideos] = useState<Video[]>([]);
    const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
    const [showAvatarUpload, setShowAvatarUpload] = useState(false);
    const [showUpload, setShowUpload] = useState(false);

    useEffect(() => {
        const loadVideos = async () => {
            const vids = await fetchVideos();
            const formatted = vids.map((video: any) => ({
                title: video.title,
                url: video.videoUrl, // 🔄 rename for UI compatibility
                tokenMint: video.tokenMint || "", // ✅ optional fallback
            }));
            setVideos(formatted);
        };
        loadVideos();
    }, []);

    const handleUpload = (video: { title: string; url: string; tokenMint: string }) => {
        setVideos((prev) => [video, ...prev]);
        setShowUpload(false);
    };

    return (
        <Router>
            <div className="min-h-screen bg-[#0f0f0f] text-white">
                <nav className="bg-[#121212] px-6 py-3 flex items-center justify-between border-b border-gray-800 shadow-sm">
                    <div className="flex items-center space-x-6">
                        <img src="/ClipChain.png" alt="ClipChain Logo" className="h-64 w-auto object-contain" />
                        <Link to="/" className="text-white text-lg font-medium hover:text-gray-300 transition">Explore</Link>
                        <Link to="/creator" className="text-white text-lg font-medium hover:text-gray-300 transition">Creator Dashboard</Link>
                    </div>
                    <div className="flex items-center space-x-4">
                        <button onClick={() => setShowUpload(!showUpload)} className="bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white px-4 py-2 rounded-full text-sm">
                            {showUpload ? "Cancel Upload" : "Upload"}
                        </button>
                        <WalletMultiButton className="!bg-purple-600 hover:!bg-purple-700 text-white rounded-full px-4 py-2 text-sm" />
                        <div className="relative group">
                            <img src={avatarUrl || "/profile.png"} alt="Profile" className="h-10 w-10 rounded-full border border-gray-600 cursor-pointer" onClick={() => setShowAvatarUpload(!showAvatarUpload)} />
                            {showAvatarUpload && (
                                <div className="absolute right-0 mt-2 z-50 bg-[#1f1f1f] p-4 rounded shadow-xl">
                                    <UploadAvatar onUpload={(url) => {
                                        setAvatarUrl(url);
                                        setShowAvatarUpload(false);
                                    }} />
                                </div>
                            )}
                        </div>
                    </div>
                </nav>
                {showUpload && <div className="p-6"><UploadVideo onUpload={handleUpload} /></div>}
                <main className="p-6 pt-0">
                    <Routes>
                        <Route path="/" element={
                            <>
                                {videos.length > 0 ? (
                                    <VideoGrid videos={videos} />
                                ) : (
                                    <div className="text-center text-gray-400 mt-16 text-lg">
                                        No videos yet. Upload one to get started!
                                    </div>
                                )}
                                <FanDashboard />
                            </>
                        } />
                        <Route path="/creator" element={<CreatorDashboard />} />
                    </Routes>
                </main>
            </div>
        </Router>
    );
};

export default AppRoutes;
